package com.suxiantao.www.po;

import java.util.Date;

public class Empinfo {
	private Integer id;
	private String name;
	private String sex;
	private Date birthday;
	private String education;
	private Integer departmentId;
	private String departmentName;
	private String mobile;
	private String address;
	private String idcardNo;
	private String pwd;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}
	
	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
	
	public String getEducation() {
		return education;
	}

	public void setEducation(String education) {
		this.education = education;
	}
	
	public Integer getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	
	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getidcardNo() {
		return idcardNo;
	}

	public void setidcardNo(String idcardNo) {
		this.idcardNo = idcardNo;
	}
	
	public String getpwd() {
		return pwd;
	}

	public void setpwd(String pwd) {
		this.pwd = pwd;
	}
	
	@Override
	public String toString() {
		return "Empinfo [id=" + id 
				+ ", name=" + name 
				+ ", sex=" + sex 
				+ ", birthday=" + birthday 
				+ ", education=" + education 
				+ ", department_id=" + departmentId
				+ ", department_name=" + departmentName 
				+ ", mobile=" + mobile
				+ ", address=" + address 
				+ ", idcardNo=" + idcardNo  
				+ ", pwd=" + pwd
				+ "]";
	}
	
}

package com.suxiantao.www.view;

import com.suxiantao.www.service.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class DelFrame {
	
	JTextField t;
	JFrame jf;

	public void launchFrame() {
		jf = new JFrame("删除员工信息");
		jf.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		jf.setBounds(200, 200, 900, 750);
		jf.setVisible(true);
		jf.setResizable(true);
		jf.setLayout(new GridLayout(3,1));
		
		JLabel l1 = new JLabel("请输入要删除的员工的id");
		t = new JTextField();
		JButton jb = new JButton("确认");
		
		jf.add(l1);	jf.add(t); jf.add(jb);
		
		jb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EmployeeDelete action = new EmployeeDelete();
				action.delete(Integer.parseInt(t.getText()));
				JFrame f = new JFrame("提示");
				JLabel l = new JLabel("员工id为" + Integer.parseInt(t.getText()) + 
										"的员工信息删除成功！", JLabel.CENTER);
				f.add(l);
				f.setBounds(350, 350, 400, 400);
				f.setVisible(true);
			}
		});
	}
}

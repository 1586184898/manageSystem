package com.suxiantao.www.view;

import java.awt.GridLayout;
import java.util.List;

import javax.swing.*;

import com.suxiantao.www.po.Empinfo;
import com.suxiantao.www.service.EmployeeQuery;

public class QueFrame {

	public void launchFrame() {
		JFrame jf = new JFrame("查看员工信息");
		jf.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		jf.setBounds(200, 200, 900, 750);
		jf.setVisible(true);
		jf.setResizable(true);
		
		List<Empinfo> result = null;
		EmployeeQuery action = new EmployeeQuery();
		result = action.query();
		jf.setLayout(new GridLayout(result.size(), 1));
		for(int i = 0; i < result.size(); i++) {
			JLabel l1 = new JLabel(
					"id:" + " " + result.get(i).getId() + "  " + 
					"姓名:" + " " + result.get(i).getName() + "  " + 
					"性别:" + " " + result.get(i).getSex() + "  " + 
					"生日:" + " " + result.get(i).getBirthday() + "  " + 
					"学历:" + " " + result.get(i).getEducation() + "  " + 
					"部门id:" + " " + result.get(i).getDepartmentId() + "  " + 
					"部门名字:" + " " + result.get(i).getDepartmentName() + "  " + 
					"电话号码:" + " " + result.get(i).getMobile() + "  " + 
					"地址:" + " " + result.get(i).getAddress() + "  " + 
					"身份证号码:" + " " + result.get(i).getidcardNo() + "  " +
					"登陆密码:" + " " +result.get(i).getpwd()
					);
			jf.add(l1);
		}
		jf.pack();
	}
}

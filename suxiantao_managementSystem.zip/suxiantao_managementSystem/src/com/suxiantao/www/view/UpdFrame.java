package com.suxiantao.www.view;

import com.suxiantao.www.service.EmployeeUpdate;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

public class UpdFrame {

	ArrayList<JTextField> list;
	
	public void launchFrame() {
		JFrame jf = new JFrame("更新员工信息");
		jf.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		jf.setBounds(200, 200, 900, 750);
		jf.setLayout(new GridLayout(2,1));
		jf.setVisible(true);
		jf.setResizable(true);
		
		JPanel jp = new JPanel();
		JPanel jp1 = new JPanel();
		jp1.setLayout(new GridLayout(11, 1));
		
		 JLabel l1 = new JLabel("请输入新的员工名字");
		 JLabel l2 = new JLabel("请输入新的员工性别");
		 JLabel l3 = new JLabel("请输入新的员工学历");
		 JLabel l4 = new JLabel("请输入新的员工部门id");
		 JLabel l5 = new JLabel("请输入新的员工部门名字");
		 JLabel l6 = new JLabel("请输入新的员工手机号");
		 JLabel l7 = new JLabel("请输入新的员工联系地址");
		 JLabel l8 = new JLabel("请输入新的员工出生日期，格式为yyyy-mm-dd");
		 JLabel l9 = new JLabel("请输入新的员工身份证号码");
		 JLabel l10 = new JLabel("请输入新的员工登陆密码");
		 JLabel l11 = new JLabel("请输入信息要修改的员工的id");
		  
		jp1.add(l1);		jp1.add(l2);		jp1.add(l3);		jp1.add(l4);		jp1.add(l5);
		jp1.add(l6);		jp1.add(l7);		jp1.add(l8);		jp1.add(l9);		jp1.add(l10);
		jp1.add(l11);
		jp.add(jp1);
		
		JPanel jp2 = new JPanel();
		jp2.setLayout(new GridLayout(11, 1));
		list = new ArrayList<JTextField>();
		JTextField t1 = new JTextField(20);		
		JTextField t2 = new JTextField(20);
		JTextField t3 = new JTextField(20);
		JTextField t4 = new JTextField(20);
		JTextField t5 = new JTextField(20);
		JTextField t6 = new JTextField(20);
		JTextField t7 = new JTextField(20);
		JTextField t8 = new JTextField(20);
		JTextField t9 = new JTextField(20);
		JTextField t10 = new JTextField(20);
		JTextField t11 = new JTextField(20);
		
		jp2.add(t1);	jp2.add(t2);	jp2.add(t3);	jp2.add(t4);	jp2.add(t5);
		jp2.add(t6);	jp2.add(t7);	jp2.add(t8);	jp2.add(t9);	jp2.add(t10);
		jp2.add(t11);
		jp.add(jp2);
		jf.add(jp);
		
		list.add(t1);	list.add(t2);	list.add(t3);	list.add(t4);	list.add(t5);
		list.add(t6);	list.add(t7);	list.add(t8);	list.add(t9);	list.add(t10);
		list.add(t11);
		
		JButton jb = new JButton("确认");
		jf.add(jb);
		jf.pack();
		
		jb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EmployeeUpdate action = new EmployeeUpdate();
				for(int i = 0; i < list.size(); i++) {
					action.update(i, list.get(i).getText());
				}
				JFrame f = new JFrame("提示");
				JLabel l = new JLabel("信息更新结束！", JLabel.CENTER);
				f.add(l);
				f.setBounds(350, 350, 400, 400);
				f.setVisible(true);
			}
		});
	}
}

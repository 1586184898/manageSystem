package com.suxiantao.www.view;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.*;

import com.suxiantao.www.po.Empinfo;
import com.suxiantao.www.service.EmployeeQuery;

public class MainFrame extends Frame {

	public static void main(String[] args) {
		new MainFrame().launchFrame();
	}
	
	public void launchFrame() {
		JFrame jf = new JFrame("员工信息管理系统");
		JLabel j0 = new JLabel("欢迎使用员工信息管理系统！请先登陆", JLabel.CENTER);
		JLabel j1 = new JLabel("登陆账号");		final JTextField jtf1 = new JTextField(20);		JPanel jp1 = new JPanel();
		JLabel j2 = new JLabel("登陆密码");		final JTextField jtf2 = new JTextField(20);		JPanel jp2 = new JPanel();
		JButton jb0 = new JButton("登陆");		JPanel jp0 = new JPanel();
		
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf.setLayout(new GridLayout(4,1));
		jf.setBounds(200, 200, 900, 750);
		jf.setVisible(true);
		jf.setResizable(false);
		
		jb0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EmployeeQuery action = new EmployeeQuery();
				List<Empinfo> result = action.query();
				boolean isLogin = false;		//用来指定登录状态
				for(int i = 0; i < result.size(); i++) {
					if(jtf1.getText().equals(result.get(i).getId().toString() )&& jtf2.getText().equals(result.get(i).getpwd())){
						isLogin = true;
					}	
				}
				
				if(isLogin == false) {
					JFrame f = new JFrame("提示");
					JLabel l = new JLabel("登陆失败！", JLabel.CENTER);
					f.add(l);
					f.setBounds(475, 475, 400, 400);
					f.setVisible(true);
				}else {
					JFrame mainF = new JFrame("员工信息管理系统");
					JButton jb1 = new JButton("增加员工信息");
					JButton jb2 = new JButton("删除员工信息");
					JButton jb3 = new JButton("更新员工信息");
					JButton jb4 = new JButton("查看员工信息");
					
					mainF.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					mainF.setLayout(new GridLayout(4,1));
					mainF.setBounds(200, 200, 900, 750);
					mainF.setVisible(true);
					mainF.setResizable(false);
					
					mainF.add(jb1);		mainF.add(jb2);		mainF.add(jb3);		mainF.add(jb4);
					
					jb1.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e){
							new AddFrame().launchFrame();
						}
					});
					
					jb2.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							new DelFrame().launchFrame();
						}
					});
					
					jb3.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							new UpdFrame().launchFrame();
						}
					});
					
					jb4.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							new QueFrame().launchFrame();
						}
					});
				}
			}
		});
		
		jp1.add(j1);	jp1.add(jtf1);	jp2.add(j2);	jp2.add(jtf2);
		jf.add(j0);		jf.add(jp1);	jf.add(jp2);	jf.add(jb0);

		
	}
}


package com.suxiantao.www.dao;

import com.suxiantao.www.po.Empinfo;
import com.suxiantao.www.util.DBConnection;

import java.sql.*;
import java.sql.Date;
import java.util.*;


public class EmployeeDao {
	
	//增加员工信息的方法
	public void addEmployee(Empinfo m) throws Exception {
		Connection conn = DBConnection.getConnection();
		String sql = "" 
				+ " insert into empinformation "
				+ " (id, name, sex, education, departmentId, departmentName,"
				+ " mobile, address, birthday, idcardNo, pwd) "
				+ " values( "
				+ "  ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ";
		
		PreparedStatement ptmt = conn.prepareStatement(sql);
		
		ptmt.setInt(1, m.getId());
		ptmt.setString(2, m.getName());
		ptmt.setString(3, m.getSex());
		ptmt.setString(4, m.getEducation());
		ptmt.setInt(5, m.getDepartmentId());
		ptmt.setString(6, m.getDepartmentName());
		ptmt.setString(7, m.getMobile());
		ptmt.setString(8, m.getAddress());
		ptmt.setDate(9, new Date(m.getBirthday().getTime()));
		ptmt.setString(10, m.getidcardNo());
		ptmt.setString(11, m.getpwd());
		
		ptmt.execute();
	}

	//删除员工信息的方法：
	public void deleteEmployee(Integer id) throws SQLException {
		Connection conn = DBConnection.getConnection();
		String sql =  "" +
		 " delete from empinformation " +
		 " where id = ? "; 
			
		PreparedStatement ptmt = conn.prepareStatement(sql);
		ptmt.setInt(1,id);
			
		ptmt.execute();
	}
		
	//修改员工信息的方法
	public void updateEmployee(Empinfo m) throws SQLException {
		Connection conn = DBConnection.getConnection();
		String sql =  "" +
		 " update empinformation " +
		 " set name = ?, sex = ?, education = ?, departmentId = ?, departmentName = ?," +
		 " mobile = ?, address = ?, birthday = ?, idcardNo = ?, pwd = ? " +
		 " where id = ? "; 
		
		PreparedStatement ptmt = conn.prepareStatement(sql);
		
		ptmt.setString(1, m.getName());
		ptmt.setString(2, m.getSex());
		ptmt.setString(3, m.getEducation());
		ptmt.setInt(4, m.getDepartmentId());
		ptmt.setString(5, m.getDepartmentName());
		ptmt.setString(6, m.getMobile());
		ptmt.setString(7, m.getAddress());
		ptmt.setDate(8, new Date(m.getBirthday().getTime()));
		ptmt.setString(9, m.getidcardNo());
		ptmt.setString(10, m.getpwd());
		ptmt.setInt(11, m.getId());
		
		ptmt.execute();
	}

	//查询全部员工的全部信息
	public List<Empinfo> query() throws Exception {          
		
		List<Empinfo> result = new ArrayList<Empinfo>();
		Connection conn = DBConnection.getConnection();
		StringBuilder sb = new StringBuilder();
		sb.append("select * from empinformation");
		
		PreparedStatement ptmt = conn.prepareStatement(sb.toString());
		ResultSet rs = ptmt.executeQuery();
		
		Empinfo p = null;
		while(rs.next()) {
			p = new Empinfo();
			p.setId(rs.getInt("id"));
			p.setName(rs.getString("name"));
			p.setSex(rs.getString("sex"));
			p.setBirthday(rs.getDate("birthday"));
			p.setEducation(rs.getString("education"));
			p.setDepartmentId(rs.getInt("departmentId"));
			p.setDepartmentName(rs.getString("departmentName"));
			p.setMobile(rs.getString("mobile"));
			p.setAddress(rs.getString("address"));
			p.setidcardNo(rs.getString("idcardNo"));
			p.setpwd(rs.getString("pwd"));
			
			result.add(p);
		}
		return result;
	}
	
}


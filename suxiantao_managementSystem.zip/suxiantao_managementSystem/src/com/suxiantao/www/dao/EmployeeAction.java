package com.suxiantao.www.dao;

import com.suxiantao.www.po.Empinfo;

import java.sql.SQLException;
import java.util.*;

public class EmployeeAction {
	
	//传进来一个Empinfo对象的参数，并且根据此参数的属性执行添加员工信息的方法
	public void add(Empinfo emp) throws Exception {
		EmployeeDao dao = new EmployeeDao();
		dao.addEmployee(emp);
	}
	
	//传进来某一个员工的id作为此方法的参数，并且执行删除此id号的员工的方法
	public void del(int id) throws SQLException  {
		EmployeeDao dao = new EmployeeDao();
		dao.deleteEmployee(id);
	}
		
	//传进来一个Empinfo对象的参数，并且根据此参数的属性执行修改员工信息的方法
	public void update(Empinfo emp) throws Exception {
		EmployeeDao dao = new EmployeeDao();
		dao.updateEmployee(emp);
	}
	
	//无参的查询方法，执行查询的方法后输出所有员工的所有信息
	public List<Empinfo> query() throws Exception {
		EmployeeDao dao = new EmployeeDao();
		return dao.query();
	}
	
}

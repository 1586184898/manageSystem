package com.suxiantao.www.service;

import java.text.*;
import java.util.Date;

import javax.swing.JFrame;
import javax.swing.JLabel;

import com.suxiantao.www.dao.EmployeeAction;
import com.suxiantao.www.po.Empinfo;

public class EmployeeUpdate {
	
	public static Empinfo emp = new Empinfo();
	
	public void update(int step, String edit) {
		
		if(step == 2) {
			emp.setName(edit);	
			
		}else if(step == 3){
			emp.setSex(edit);
				
		}else if(step == 4) {
			emp.setEducation(edit);
				
		}else if(step == 5){
			emp.setDepartmentId(Integer.valueOf(edit));
				
		}else if(step == 6 ) {	
			emp.setDepartmentName(edit);
				
		}else if(step == 7) {
			emp.setMobile(edit);
				
		}else if(step == 8) {
			emp.setAddress(edit);
				
		}else if(step == 9) {
			SimpleDateFormat sf = new SimpleDateFormat("yyyy-mm-dd");
			Date startWorkDay = null;
			try {
				startWorkDay = sf.parse(edit);
				emp.setBirthday(startWorkDay);
			} catch (ParseException e) {
				/* 当输入的日期格式不正确的时候，会弹出提示窗口，
				 * 此时只要在文本框内重新输入正确的日期格式即可，无需重新输入所有信息
				 */
				e.printStackTrace();
				JFrame f = new JFrame("提示");
				JLabel l = new JLabel("输入的日期格式不正确！", JLabel.CENTER);
				f.add(l);
				f.setBounds(475, 475, 400, 400);
				f.setVisible(true);
				e.printStackTrace();
			}
				
		}else if(step == 10) {
			emp.setidcardNo(edit);
		
		}else if(step == 11) {
			emp.setpwd(edit);
				
		}else if(step == 12) {
			emp.setId(Integer.valueOf(edit));	
			try {
				EmployeeAction action = new EmployeeAction();
				action.update(emp);
				System.out.println("修改员工基本信息成功");
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("修改员工基本信息失败");
			}
		}
	}
}
package com.suxiantao.www.service;

import java.util.*;

import com.suxiantao.www.dao.EmployeeAction;
import com.suxiantao.www.po.Empinfo;

public class EmployeeQuery {
	
	public List<Integer> NUM = new LinkedList<Integer>();
	public List<String> PWD = new LinkedList<String>();
	
	public List<Empinfo> query() {
		
		EmployeeAction action = new EmployeeAction();
		
		List<Empinfo> result = null;
		try {
			result = action.query();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
}

package com.suxiantao.www.service;

import java.sql.SQLException;

import com.suxiantao.www.dao.EmployeeAction;

public class EmployeeDelete {
	
	public void delete(int id) {
		EmployeeAction action = new EmployeeAction();
		//在执行delete方法时，必须要设置该方法中的参数，参数为员工的id号，执行后删除该id号的员工的信息
			try {
				action.del(id);
			} catch (SQLException e) {
				e.printStackTrace();
			}
	}
}
